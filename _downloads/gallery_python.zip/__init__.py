r"""
AbiPy examples
==============

There are a variety of ways to use AbiPy, and most of them are
illustrated in the examples in this directory.
"""
